package com.deepika.assignment2;
import java.util.Scanner;
public class StudentDetails {
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	       
	        System.out.println("Enter Full Name with Initial:");
	        String fullName = scanner.nextLine();
	        
	        System.out.println("Enter Roll Number:");
	        String rollNumber = scanner.nextLine();
	        
	        System.out.println("Enter Grade:");
	        String grade = scanner.nextLine();
	        
	        System.out.println("Enter Percentage:");
	        String percentage = scanner.nextLine();
	        
	       
	        System.out.println(fullName);
	        System.out.println(rollNumber);
	        System.out.println(" " + grade);
	        System.out.println(" " + percentage);
	        
	        scanner.close();
	    }
	}


